package com.homecontroller.view.fragment;

import android.support.v4.app.Fragment;

/**
 * Created by gmra on 2016-05-06.
 */
public class BaseFragment extends Fragment {
}
