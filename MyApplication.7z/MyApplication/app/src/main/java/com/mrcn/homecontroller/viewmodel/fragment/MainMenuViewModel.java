package com.mrcn.homecontroller.viewmodel.fragment;

import com.mrcn.homecontroller.viewmodel.BaseViewModel;

/**
 * Created by gmra on 2016-05-11.
 */
public class MainMenuViewModel extends BaseViewModel {
}
