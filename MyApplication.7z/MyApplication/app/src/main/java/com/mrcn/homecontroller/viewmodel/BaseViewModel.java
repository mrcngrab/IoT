package com.mrcn.homecontroller.viewmodel;

import android.databinding.BaseObservable;

/**
 * Created by gmra on 2016-05-11.
 */
public class BaseViewModel extends BaseObservable {
}
